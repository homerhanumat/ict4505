/*
window.addEventListener('load', function() {
    const mainLinks = Array.from(document.querySelectorAll('.main a'));
    console.log(mainLinks);
    mainLinks.forEach(function() {
        console.log("hello");
        this.addEventListener('mouseover', function() {
            console.log(this);
            const line = window.getComputedStyle(this, '::after');
            console.log(line);
        });
    });
});
    */